# layout_linkaja

UTS MOBILE clone layout LinkAja

1. splash screen
> ![splash screen](assets/splashscreen.png)
2. home
> ![home page](assets/homePage.png)
3. history pending
> ![splash screen](assets/history1.png)
4. history done
> ![splash screen](assets/history2.png)
5. account
> ![splash screen](assets/account.png)
